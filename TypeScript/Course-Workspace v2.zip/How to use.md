How to use

Run "npm install" to install the required dependencies

Run "tsc" to compile the TypeScript code

??[Run "npm install lite-server --save-dev]??

Run "npm start" to run the development server (lite-server)